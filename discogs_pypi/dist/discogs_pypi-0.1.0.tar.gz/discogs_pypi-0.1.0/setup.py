# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['discogs_pypi']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0',
 'numpy>=1.23.5,<2.0.0',
 'oauth2>=1.9.0.post1,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'requests>=2.28.1,<3.0.0',
 'selenium>=4.7.2,<5.0.0']

setup_kwargs = {
    'name': 'discogs-pypi',
    'version': '0.1.0',
    'description': 'This package contains several functions related to collecting data related to music releases from Discogs. There are nine functions in total that create and authorize user credentials to obtain data, obtain data on music releases from the artists of their choosing, make summary statistics and a data visualization of the music data, create a readable data frame from the user wishlist based on listings in the Discogs marketplace, and combine both datasets to indicate whether the user has in the releases data one of the releases in their wishlist.',
    'long_description': "# discogs_pypi \n\n![](https://github.com/camilla-zhang/discogs_pypi/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/camilla-zhang/discogs_pypi/branch/main/graph/badge.svg)](https://codecov.io/gh/camilla-zhang/discogs_pypi) ![Release](https://github.com/camilla-zhang/discogs_pypi/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/discogs_pypi/badge/?version=latest)](https://discogs_pypi.readthedocs.io/en/latest/?badge=latest)\n\nThis package contains several functions related to collecting data related to music releases from the Discogs website\n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ discogs_pypi\n```\n\n## Github Link\n\nhttps://github.com/camilla-zhang/discogs_py\n\n## Features\n\n###1. User Authentication\nWith this package, the user should already have an account with Discogs. There is typically a strenuous 5-step process to obtain data, where the user must frequently enter in and copy-paste several different credentials. Using the functions provided however, they will be able to easily obtain release information without having to interact with the Discogs website at all and only need a username and password (given that they have never created developer applications on the website before).\n###2. Extract Data\nWe obtain two datasets:\n1. Artist Releases: The user can enter in one or more numeric artist IDs (each ID can be found on the top-right corner of an artist's Discogs URL), and receive a list of releases for the selected artists as well as basic information on each release\n2. User Wantlist: The user can get data that displays a list of releases in their wantlist, with additional data for each release (i.e. genre, artists affiliated, etc.)\n3. Artist Releases and User Affiliation: A dataset of the original artist releases with an additional variable indicating whether a specified user has that release in their own wantlist\n###3. Summary Statistics\n1. A table containing basic info for each artist based on their release history (i.e. years active, average collectors per release, etc)\n2. A data visualization showing the average number of wantlisters and collectors for each release of each selected artist.\n\n## Dependencies\n\n- python = ^3.8\n- oauth2 = ^1.9.0.post1\n- requests = ^2.28.1\n- selenium = ^4.7.2\n- numpy = ^1.23.4\n- pandas = ^1.5.1\n- matplotlib = ^3.6.2\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://discogs_pypi.readthedocs.io/en/latest/\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/camilla-zhang/discogs_pypi/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n",
    'author': 'Camilla Zhang',
    'author_email': '94077724+camilla-zhang@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
